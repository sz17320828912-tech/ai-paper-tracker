#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="$PROJECT_DIR/.venv/bin/python"
CONFIG_PATH="${PAPERS_CONFIG:-$PROJECT_DIR/config/config.yaml}"
DB_PATH="${PAPERS_DB:-$PROJECT_DIR/data/research_radar.db}"

cd "$PROJECT_DIR"

usage() {
  echo "用法："
  echo "  ./papers.sh setup"
  echo "  ./papers.sh daily"
  echo "  ./papers.sh weekly"
  echo "  ./papers.sh range YYYY-MM-DD YYYY-MM-DD"
  echo "  ./papers.sh web"
  echo "  ./papers.sh doctor"
}

if [[ "${1:-}" == "setup" ]]; then
  SETUP_PYTHON="${PAPERS_PYTHON:-python3}"
  if ! command -v "$SETUP_PYTHON" >/dev/null 2>&1; then
    echo "错误：未找到 Python 3。可通过 PAPERS_PYTHON 指定解释器。" >&2
    exit 2
  fi
  if ! "$SETUP_PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)'; then
    echo "错误：需要 Python 3.11 或更高版本，当前是 $($SETUP_PYTHON --version 2>&1)。" >&2
    echo "安装新版本后可运行：PAPERS_PYTHON=/path/to/python3 ./papers.sh setup" >&2
    exit 2
  fi
  if [[ -x "$PYTHON_BIN" ]] && ! "$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)'; then
    echo "错误：现有 .venv 的 Python 版本低于 3.11。请移走该目录后重新运行 setup。" >&2
    exit 2
  fi
  if [[ ! -x "$PYTHON_BIN" ]]; then
    "$SETUP_PYTHON" -m venv "$PROJECT_DIR/.venv"
  fi
  "$PYTHON_BIN" -m pip install --upgrade pip
  "$PYTHON_BIN" -m pip install -r "$PROJECT_DIR/requirements.txt"
  if [[ ! -f "$CONFIG_PATH" ]]; then
    cp "$PROJECT_DIR/config/config.example.yaml" "$CONFIG_PATH"
  fi
  if [[ ! -f "$PROJECT_DIR/.env" ]]; then
    cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
  fi
  mkdir -p "$PROJECT_DIR/data" "$PROJECT_DIR/output"
  echo "安装完成。请在 $PROJECT_DIR/.env 填写 DEEPSEEK_API_KEY，然后运行 ./papers.sh web"
  exit 0
fi

if [[ ! -x "$PYTHON_BIN" ]]; then
  echo "错误：未找到项目 Python 环境：$PYTHON_BIN" >&2
  echo "请在项目目录运行：./papers.sh setup" >&2
  exit 2
fi

if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "错误：未找到配置文件：$CONFIG_PATH" >&2
  exit 2
fi

config_value() {
  "$PYTHON_BIN" - "$CONFIG_PATH" "$1" <<'PY'
import sys
from pathlib import Path

import yaml

data = yaml.safe_load(Path(sys.argv[1]).read_text(encoding="utf-8")) or {}
value = data
for part in sys.argv[2].split("."):
    value = value.get(part, "") if isinstance(value, dict) else ""
print(value)
PY
}

check_api_key() {
  if [[ "${PAPERS_SKIP_KEY_CHECK:-0}" == "1" ]]; then
    return 0
  fi

  local model provider key_name
  model="$(config_value llm.model)"
  provider="${model%%/*}"
  case "$provider" in
    openai) key_name="OPENAI_API_KEY" ;;
    gemini) key_name="GEMINI_API_KEY" ;;
    anthropic) key_name="ANTHROPIC_API_KEY" ;;
    deepseek) key_name="DEEPSEEK_API_KEY" ;;
    *) return 0 ;;
  esac

  if ! "$PYTHON_BIN" - "$PROJECT_DIR" "$model" <<'PY'
import sys
from pathlib import Path

from src.core.secrets import ensure_provider_key

raise SystemExit(0 if ensure_provider_key(sys.argv[2], Path(sys.argv[1])) else 1)
PY
  then
    echo "错误：模型 $model 需要 ${key_name}。" >&2
    echo "请把密钥写入 $PROJECT_DIR/.env，或在环境变量中设置。" >&2
    exit 2
  fi
}

run_digest() {
  check_api_key
  "$PYTHON_BIN" -m src.cli digest \
    --config "$CONFIG_PATH" \
    --db "$DB_PATH" \
    --no-interactive \
    --skip-validation \
    "$@"
}

command_name="${1:-}"
case "$command_name" in
  daily)
    # Incremental mode: first run covers the previous seven days; later runs resume from checkpoint.
    run_digest
    ;;
  weekly)
    read -r start_date end_date < <("$PYTHON_BIN" - <<'PY'
from datetime import datetime, timedelta, timezone

end = datetime.now(timezone.utc).date()
print((end - timedelta(days=6)).isoformat(), end.isoformat())
PY
    )
    run_digest --since "$start_date" --until "$end_date"
    ;;
  range)
    if [[ $# -ne 3 ]]; then
      usage >&2
      exit 2
    fi
    "$PYTHON_BIN" - "$2" "$3" <<'PY'
import sys
from datetime import date

try:
    start = date.fromisoformat(sys.argv[1])
    end = date.fromisoformat(sys.argv[2])
except ValueError as exc:
    raise SystemExit(f"日期格式错误，应为 YYYY-MM-DD：{exc}")
if start > end:
    raise SystemExit("日期范围错误：开始日期不能晚于结束日期")
PY
    run_digest --since "$2" --until "$3"
    ;;
  web)
    check_api_key
    "$PYTHON_BIN" -m src.web.app "${@:2}"
    ;;
  doctor)
    model="$(config_value llm.model)"
    min_score="$(config_value summary.min_score)"
    echo "项目目录：$PROJECT_DIR"
    echo "Python：$($PYTHON_BIN --version 2>&1)"
    echo "默认模型：$model"
    echo "相关性阈值：$min_score"
    echo "报告目录：$PROJECT_DIR/output"
    if (PAPERS_SKIP_KEY_CHECK=0 check_api_key) >/dev/null 2>&1; then
      echo "API Key：已配置"
    else
      echo "API Key：未配置（运行前请填写 $PROJECT_DIR/.env）"
    fi
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    usage >&2
    exit 2
    ;;
esac
