from datetime import datetime, timezone

from src.core.config import SourcesConfig
from src.core.models import Paper
from src.profiles.schema import UserProfile
from src.ranking.rerank_llm import RankedPaper
from src.reports import get_date_range, short_model_name, source_label
from src.reports.markdown import format_authors
from src.summarization.llm_client import TokenUsage


def _source_badge_color(source_type: str) -> str:
    """Return a badge color for the source type."""
    if source_type in ("arxiv_api", "arxiv_rss", "arxiv"):
        return "#b31b1b"
    if source_type == "inspire":
        return "#1a5276"
    return "#666"


def _detail_row(label: str, value: str, css_class: str = "") -> str:
    if not value:
        return ""
    class_attr = f" {css_class}" if css_class else ""
    return f"""
    <section class="paper-section{class_attr}">
        <h3>{_escape(label)}</h3>
        <p>{_escape(value)}</p>
    </section>"""


def generate_html_report(
    ranked_papers: list[RankedPaper],
    token_usage: TokenUsage | None = None,
    profile: UserProfile | None = None,
    sources_config: SourcesConfig | None = None,
    total_fetched: int = 0,
    model: str = "",
    title: str = "Research Radar Digest",
    expanded_keywords: list[str] | None = None,
    pipeline_stats: dict | None = None,
    all_papers: list[Paper] | None = None,
) -> str:
    """Generate a standalone, interactive HTML digest containing only retained papers."""
    del all_papers  # Low-score papers must never appear in the final report.
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    expanded_keywords = expanded_keywords or []
    pipeline_stats = pipeline_stats or {}
    date_range = get_date_range(ranked_papers)
    configured_min_score = int(pipeline_stats.get("min_score", 1))

    digest_window = pipeline_stats.get("digest_window", "")
    digest_window_html = ""
    if digest_window:
        digest_window_html = f'<p class="digest-window">本次时间范围：{_escape(digest_window)}</p>'

    summary_rows = ""
    if date_range:
        summary_rows += f"<tr><td>保留论文日期范围</td><td>{_escape(date_range)}</td></tr>"
    summary_rows += f"<tr><td>Total papers fetched / 总检索论文数</td><td>{total_fetched}</td></tr>"
    summary_rows += f"<tr><td>Papers shown / 最终保留论文数</td><td>{len(ranked_papers)}</td></tr>"
    summary_rows += f"<tr><td>Minimum relevance score / 当前阈值</td><td>{configured_min_score}/10</td></tr>"
    if sources_config and sources_config.arxiv.enabled and sources_config.arxiv.categories:
        categories = _escape(", ".join(sources_config.arxiv.categories))
        summary_rows += f"<tr><td>arXiv categories</td><td>{categories}</td></tr>"

    summary_html = f"""
    <section class="panel">
        <h2>Search Summary / 检索概览</h2>
        <table class="summary-table">{summary_rows}</table>
    </section>"""

    profile_html = ""
    if profile:
        profile_rows = ""
        if profile.topic_interests:
            value = _escape(", ".join(profile.topic_interests))
            profile_rows += f"<tr><td>Topic interests</td><td>{value}</td></tr>"
        if profile.required_signals:
            value = _escape(", ".join(profile.required_signals))
            profile_rows += f"<tr><td>Required signals</td><td>{value}</td></tr>"
        if profile.negative_filters:
            value = _escape(", ".join(profile.negative_filters))
            profile_rows += f"<tr><td>Negative filters</td><td>{value}</td></tr>"
        if profile.project_context:
            profile_rows += f"<tr><td>Project context</td><td>{_escape(profile.project_context)}</td></tr>"
        if profile.expertise_level:
            profile_rows += f"<tr><td>Expertise level</td><td>{_escape(profile.expertise_level)}</td></tr>"
        profile_html = f"""
        <details class="panel compact-panel">
            <summary><strong>User Profile / 研究画像</strong></summary>
            <table class="summary-table">{profile_rows}</table>
        </details>"""

    synonym_html = ""
    if expanded_keywords and profile and profile.topic_interests:
        original = _escape(", ".join(profile.topic_interests))
        expanded = _escape(", ".join(expanded_keywords))
        synonym_html = f"""
        <details class="panel compact-panel">
            <summary><strong>Keyword Expansion / 关键词扩展</strong></summary>
            <p><strong>Original interests:</strong> {original}</p>
            <p><strong>Expanded to:</strong> {expanded}</p>
        </details>"""

    stats_html = ""
    if pipeline_stats:
        arxiv_count = pipeline_stats.get("arxiv_fetched", 0)
        inspire_count = pipeline_stats.get("inspire_fetched", 0)
        unique = pipeline_stats.get("unique_papers", 0)
        passed = pipeline_stats.get("keyword_passed", 0)
        rejected = pipeline_stats.get("keyword_rejected", 0)
        scored = pipeline_stats.get("llm_scored", 0)
        final = pipeline_stats.get("final_count", len(ranked_papers))
        stats_html = f"""
        <details class="panel compact-panel">
            <summary><strong>Pipeline Stats / 处理统计</strong></summary>
            <ul>
                <li><strong>Sources:</strong> {arxiv_count} from arXiv, {inspire_count} from INSPIRE</li>
                <li><strong>After dedup:</strong> {unique} unique papers</li>
                <li><strong>Keyword filter:</strong> {passed} passed, {rejected} rejected</li>
                <li><strong>LLM scored:</strong> {scored} papers</li>
                <li><strong>Final digest:</strong> {final} papers</li>
            </ul>
        </details>"""

    rubric_html = """
    <details class="panel compact-panel">
        <summary><strong>Scoring Rubric / 评分标准</strong></summary>
        <table class="rubric">
            <tr><td class="score-cell score-high">9-10</td><td>核心方法与当前项目直接重合，属于必读论文。</td></tr>
            <tr><td class="score-cell score-good">7-8</td><td>同一子领域，方法或结论可直接迁移。</td></tr>
            <tr><td class="score-cell score-mid">4-6</td><td>相邻方向或间接相关，不进入当前报告。</td></tr>
            <tr><td class="score-cell score-low">1-3</td><td>仅表面关键词重合或方向不同。</td></tr>
        </table>
    </details>"""

    papers_html = ""
    for index, ranked in enumerate(ranked_papers, 1):
        paper = ranked.paper
        author_text = format_authors(paper.authors)
        publication_date = paper.submitted_date.strftime("%Y-%m-%d")
        score_color = _score_color(ranked.relevance_score)
        badge_color = _source_badge_color(paper.source_type)
        source_tag = source_label(paper.source_type)
        display_title = ranked.chinese_title or paper.title
        original_title_html = ""
        if ranked.chinese_title:
            original_title_html = f'<p class="original-title">{_escape(paper.title)}</p>'

        links = f'<a href="{_escape(paper.source_url)}" target="_blank" rel="noopener">arXiv 页面 ↗</a>'
        if paper.pdf_url:
            links += f' <a href="{_escape(paper.pdf_url)}" target="_blank" rel="noopener">PDF ↗</a>'

        has_new_structured_fields = any(
            [
                ranked.chinese_title,
                ranked.abstract_zh,
                ranked.research_problem,
                ranked.core_method,
                ranked.core_contribution,
                ranked.relationship_to_research,
                ranked.potential_inspiration,
            ]
        )
        structured_html = ""
        if has_new_structured_fields:
            structured_html = "".join(
                [
                    _detail_row("中文摘要（翻译）", ranked.abstract_zh, "abstract-translation"),
                    _detail_row("研究问题", ranked.research_problem),
                    _detail_row("核心方法", ranked.core_method),
                    _detail_row("核心贡献", ranked.core_contribution),
                    _detail_row(
                        "与我的研究方向的关系",
                        ranked.relationship_to_research or ranked.why_relevant,
                        "relation",
                    ),
                    _detail_row("对我可能有启发的地方", ranked.potential_inspiration, "inspiration"),
                    _detail_row("整体摘要", ranked.summary),
                ]
            )

        model_label = short_model_name(model)
        trust_html = ""
        if ranked.abstract_takeaway:
            trust_html += f"""
            <section class="trust-section from-paper">
                <span class="trust-label">From the paper:</span>
                <p>{_escape(ranked.abstract_takeaway)}</p>
            </section>"""
        if ranked.why_relevant and not ranked.relationship_to_research:
            trust_html += f"""
            <section class="trust-section our-assessment">
                <span class="trust-label">{_escape(model_label)} - Assessment:</span>
                <p>{_escape(ranked.why_relevant)}</p>
            </section>"""
        if not structured_html and not trust_html:
            trust_html = f"""
            <p class="reasoning"><strong>Why this matters:</strong> {_escape(ranked.reasoning)}</p>
            <p class="summary"><strong>Summary:</strong> {_escape(ranked.summary)}</p>"""

        abstract_html = ""
        if paper.abstract:
            abstract_html = f"""
            <details class="abstract">
                <summary>Abstract</summary>
                <p>{_escape(paper.abstract)}</p>
            </details>"""

        search_blob = " ".join(
            [
                paper.title,
                ranked.chinese_title,
                ranked.abstract_zh,
                author_text,
                paper.abstract,
                ranked.research_problem,
                ranked.core_method,
                ranked.core_contribution,
                ranked.relationship_to_research,
                ranked.potential_inspiration,
            ]
        ).lower()

        papers_html += f"""
        <article class="paper" data-score="{ranked.relevance_score}" data-search="{_escape(search_blob)}">
            <details open>
                <summary class="paper-toggle">
                    <div class="paper-heading">
                        <span class="rank">#{index}</span>
                        <div class="titles">
                            <h2>{_escape(display_title)}</h2>
                            {original_title_html}
                        </div>
                        <span class="score" style="background:{score_color}">Relevance Score {ranked.relevance_score}/10</span>
                    </div>
                </summary>
                <div class="paper-body">
                    <div class="meta">
                        <span class="source-badge" style="background:{badge_color}">{_escape(source_tag)}</span>
                        <span>日期：{publication_date}</span>
                        <span>{_escape(', '.join(paper.categories[:5]))}</span>
                    </div>
                    <p class="authors"><strong>作者：</strong>{_escape(author_text)}</p>
                    {structured_html}
                    {trust_html}
                    {abstract_html}
                    <p class="links">{links}</p>
                </div>
            </details>
        </article>"""

    no_papers = ""
    if not ranked_papers:
        no_papers = '<div class="empty">本次没有达到阈值的论文。No papers matched your profile for this run.</div>'

    controls = ""
    if ranked_papers:
        options = "".join(
            f'<option value="{score}"{" selected" if score == configured_min_score else ""}>{score} 分及以上</option>'
            for score in range(1, 11)
        )
        controls = f"""
        <section class="controls" aria-label="论文筛选">
            <label>关键词搜索<input id="paper-search" type="search" placeholder="标题、作者、方法、关键词…"></label>
            <label>评分筛选<select id="score-filter">{options}</select></label>
            <span id="visible-count">显示 {len(ranked_papers)} 篇</span>
            <button id="toggle-all" type="button">全部折叠</button>
        </section>"""

    footer_parts = []
    if model:
        footer_parts.append(f"Model: {_escape(model)}")
    if token_usage:
        footer_parts.append(_escape(token_usage.report()))
    footer = f'<p class="footer">{" | ".join(footer_parts)}</p>' if footer_parts else ""

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{_escape(title)}</title>
    <style>
        :root {{ --ink:#172033; --muted:#64748b; --line:#dfe5ec; --accent:#3159d9; --paper:#fff; }}
        * {{ box-sizing:border-box; }}
        body {{ margin:0; background:#f4f7fb; color:var(--ink); font:15px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }}
        .page {{ width:min(1080px, calc(100% - 32px)); margin:0 auto; padding:34px 0 60px; }}
        .hero {{ padding:30px; border-radius:20px; color:white; background:linear-gradient(135deg,#152449,#3159d9); box-shadow:0 16px 40px #2338762b; }}
        .hero h1 {{ margin:0 0 6px; font-size:clamp(26px,5vw,42px); line-height:1.2; }}
        .subtitle {{ margin:0; color:#dce5ff; }}
        .digest-window {{ margin:16px 0 0; padding:10px 14px; border-radius:10px; background:#ffffff18; }}
        .overview {{ display:grid; grid-template-columns:1.15fr .85fr; gap:16px; margin:18px 0; }}
        .panel,.controls,.paper,.empty {{ background:var(--paper); border:1px solid var(--line); border-radius:14px; box-shadow:0 8px 24px #263b6810; }}
        .panel {{ padding:18px 22px; margin-bottom:12px; }}
        .panel h2 {{ margin:0 0 10px; font-size:17px; }}
        .compact-panel summary {{ cursor:pointer; color:#34425b; }}
        .summary-table,.rubric {{ width:100%; border-collapse:collapse; margin-top:8px; }}
        .summary-table td,.rubric td {{ padding:8px 6px; border-bottom:1px solid #edf0f4; vertical-align:top; }}
        .summary-table td:first-child {{ width:44%; color:var(--muted); font-weight:600; }}
        .score-cell {{ width:66px; color:white; text-align:center; border-radius:7px; font-weight:800; }}
        .score-high {{ background:#16764b; }} .score-good {{ background:#4f8b62; }} .score-mid {{ background:#b98216; }} .score-low {{ background:#8993a2; }}
        .controls {{ position:sticky; top:10px; z-index:5; display:flex; gap:12px; align-items:end; flex-wrap:wrap; padding:14px; margin:20px 0; }}
        .controls label {{ display:grid; gap:4px; color:var(--muted); font-size:12px; font-weight:700; }}
        .controls input,.controls select,.controls button {{ min-height:40px; padding:8px 12px; border:1px solid #ccd4df; border-radius:9px; background:white; color:var(--ink); font:inherit; }}
        .controls input {{ width:min(430px,65vw); }}
        .controls button {{ cursor:pointer; margin-left:auto; }}
        #visible-count {{ align-self:center; color:var(--muted); }}
        .paper {{ margin-bottom:16px; overflow:hidden; }}
        .paper[hidden] {{ display:none; }}
        .paper-toggle {{ cursor:pointer; list-style:none; padding:20px 22px; }}
        .paper-toggle::-webkit-details-marker {{ display:none; }}
        .paper-heading {{ display:grid; grid-template-columns:auto 1fr auto; gap:14px; align-items:start; }}
        .rank {{ color:#8c98aa; font-weight:800; }}
        .titles h2 {{ margin:0; font-size:20px; line-height:1.35; }}
        .original-title {{ margin:4px 0 0; color:var(--muted); font-size:14px; }}
        .score {{ padding:5px 10px; color:white; border-radius:999px; font-size:12px; font-weight:800; white-space:nowrap; }}
        .paper-body {{ padding:0 22px 22px; border-top:1px solid #edf0f4; }}
        .meta {{ display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin:16px 0 8px; color:var(--muted); font-size:13px; }}
        .source-badge {{ padding:2px 8px; border-radius:5px; color:white; font-size:11px; font-weight:800; }}
        .authors {{ color:#4c586d; }}
        .paper-section {{ margin:12px 0; padding:12px 15px; border-left:3px solid #92a0b5; background:#f8fafc; border-radius:0 9px 9px 0; }}
        .paper-section h3 {{ margin:0 0 3px; color:#43516a; font-size:13px; }}
        .paper-section p,.trust-section p {{ margin:0; }}
        .paper-section.relation {{ border-left-color:#3159d9; background:#f2f5ff; }}
        .paper-section.inspiration {{ border-left-color:#a8700c; background:#fff9eb; }}
        .trust-section {{ margin:12px 0; padding:12px 15px; border-radius:9px; }}
        .trust-label {{ font-size:12px; font-weight:800; }}
        .from-paper {{ background:#eef8f1; }} .from-paper .trust-label {{ color:#16764b; }}
        .our-assessment {{ background:#f2f5ff; }} .our-assessment .trust-label {{ color:#3159d9; }}
        .abstract {{ margin-top:14px; padding:10px 13px; border:1px solid var(--line); border-radius:9px; color:#4c586d; }}
        .abstract summary {{ cursor:pointer; font-weight:700; }}
        .links {{ display:flex; gap:10px; margin:16px 0 0; }}
        .links a {{ padding:7px 11px; border-radius:8px; color:white; background:var(--accent); text-decoration:none; font-weight:700; }}
        .empty {{ padding:30px; text-align:center; color:var(--muted); }}
        .footer {{ color:#8792a3; font-size:12px; text-align:center; margin-top:28px; }}
        @media (max-width:760px) {{ .overview {{ grid-template-columns:1fr; }} .paper-heading {{ grid-template-columns:auto 1fr; }} .score {{ grid-column:2; width:max-content; }} .controls {{ position:static; }} .controls button {{ margin-left:0; }} }}
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
        onload="renderMathInElement(document.body, {{delimiters:[{{left:'$$',right:'$$',display: true}},{{left:'$',right:'$',display: false}}],throwOnError: false}});"></script>
</head>
<body>
<main class="page">
    <header class="hero">
        <h1>{_escape(title)}</h1>
        <p class="subtitle">生成时间：{now}</p>
        {digest_window_html}
    </header>
    <div class="overview"><div>{summary_html}{stats_html}</div><div>{profile_html}{synonym_html}{rubric_html}</div></div>
    {controls}
    {no_papers}
    <section id="papers">{papers_html}</section>
    {footer}
</main>
<script>
(() => {{
    const cards = [...document.querySelectorAll('.paper')];
    const search = document.getElementById('paper-search');
    const score = document.getElementById('score-filter');
    const count = document.getElementById('visible-count');
    const toggle = document.getElementById('toggle-all');
    const applyFilters = () => {{
        const query = (search?.value || '').trim().toLowerCase();
        const minimum = Number(score?.value || 1);
        let visible = 0;
        cards.forEach(card => {{
            const show = Number(card.dataset.score) >= minimum && card.dataset.search.includes(query);
            card.hidden = !show;
            if (show) visible += 1;
        }});
        if (count) count.textContent = `显示 ${{visible}} 篇`;
    }};
    search?.addEventListener('input', applyFilters);
    score?.addEventListener('change', applyFilters);
    toggle?.addEventListener('click', () => {{
        const shouldOpen = toggle.textContent === '全部展开';
        cards.filter(card => !card.hidden).forEach(card => card.querySelector(':scope > details').open = shouldOpen);
        toggle.textContent = shouldOpen ? '全部折叠' : '全部展开';
    }});
    applyFilters();
}})();
</script>
</body>
</html>"""


def _score_color(score: int) -> str:
    """Return a color for the relevance score badge."""
    if score >= 8:
        return "#2d8a4e"
    if score >= 6:
        return "#5a9e6f"
    if score >= 4:
        return "#b8860b"
    return "#999"


def _escape(text: str) -> str:
    """Basic HTML escaping."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )
