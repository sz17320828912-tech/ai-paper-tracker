"""Local web interface for interactive paper searches."""
