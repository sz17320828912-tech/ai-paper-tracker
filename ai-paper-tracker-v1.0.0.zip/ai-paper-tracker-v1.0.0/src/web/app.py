"""Flask application for the local interactive paper tracker."""

import argparse
import os
import threading
import uuid
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_from_directory

from src.core.config import load_config
from src.core.secrets import ensure_provider_key
from src.web.service import PROJECT_ROOT, run_interactive_search, serialize_ranked_paper

app = Flask(__name__)
executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="paper-search")
jobs: dict[str, dict] = {}
jobs_lock = threading.Lock()


def _set_job(job_id: str, **updates) -> None:
    with jobs_lock:
        jobs[job_id].update(updates)


def _run_job(job_id: str, start: str, end: str, direction: str) -> None:
    _set_job(job_id, status="running", message="正在生成检索词并查询 arXiv…")
    try:
        result = run_interactive_search(start, end, direction)
        papers = [serialize_ranked_paper(item) for item in result["ranked_papers"]]
        md_path = result.get("md_path")
        html_path = result.get("html_path")
        payload = {
            "status": "complete",
            "message": f"完成：保留 {len(papers)} 篇高相关论文",
            "papers": papers,
            "stats": result["stats"],
            "search_terms": result["search_terms"],
            "direction": result["direction"],
            "markdown_url": f"/reports/{Path(md_path).name}" if md_path else None,
            "html_url": f"/reports/{Path(html_path).name}" if html_path else None,
        }
        _set_job(job_id, **payload)
    except Exception as exc:
        _set_job(job_id, status="failed", message=str(exc))


@app.get("/")
def index():
    config = load_config(PROJECT_ROOT / "config" / "config.yaml")
    today = datetime.now(timezone.utc).date()
    return render_template(
        "index.html",
        today=today.isoformat(),
        week_ago=(today - timedelta(days=6)).isoformat(),
        model=config.llm.model,
        min_score=config.summary.min_score,
    )


@app.get("/api/health")
def health():
    config = load_config(PROJECT_ROOT / "config" / "config.yaml")
    return jsonify({
        "ok": True,
        "model": config.llm.model,
        "min_score": config.summary.min_score,
        "api_key_ready": ensure_provider_key(config.llm.model),
    })


@app.post("/api/jobs")
def create_job():
    body = request.get_json(silent=True) or {}
    start = str(body.get("start", ""))
    end = str(body.get("end", ""))
    direction = str(body.get("direction", ""))
    try:
        from src.web.service import parse_date_range, validate_direction

        parse_date_range(start, end)
        direction = validate_direction(direction)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    job_id = uuid.uuid4().hex
    with jobs_lock:
        jobs[job_id] = {
            "id": job_id,
            "status": "queued",
            "message": "任务已进入队列…",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    executor.submit(_run_job, job_id, start, end, direction)
    return jsonify({"job_id": job_id}), 202


@app.get("/api/jobs/<job_id>")
def get_job(job_id: str):
    with jobs_lock:
        job = jobs.get(job_id)
        if job is None:
            return jsonify({"error": "未找到该任务"}), 404
        return jsonify(dict(job))


@app.get("/reports/<path:filename>")
def report_file(filename: str):
    return send_from_directory(PROJECT_ROOT / "output", filename, as_attachment=False)


def main() -> None:
    parser = argparse.ArgumentParser(description="Local AI paper tracker web interface")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PAPERS_WEB_PORT", "8765")))
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args()
    url = f"http://{args.host}:{args.port}"
    if not args.no_open:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    print(f"Paper tracker: {url}")
    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
