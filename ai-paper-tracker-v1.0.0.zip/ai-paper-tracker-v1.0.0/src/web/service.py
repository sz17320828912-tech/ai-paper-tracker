"""Dynamic search service used by the local web application."""

import json
from copy import deepcopy
from datetime import date, datetime, time, timezone
from pathlib import Path

from src.core.config import AppConfig, LLMConfig, load_config
from src.profiles.schema import UserProfile
from src.summarization.llm_client import call_llm
from src.workflows.daily_digest import run_daily_digest

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def parse_date_range(start_text: str, end_text: str) -> tuple[datetime, datetime]:
    try:
        start_day = date.fromisoformat(start_text)
        end_day = date.fromisoformat(end_text)
    except ValueError as exc:
        raise ValueError("日期格式必须是 YYYY-MM-DD") from exc
    if start_day > end_day:
        raise ValueError("开始日期不能晚于结束日期")
    if (end_day - start_day).days > 30:
        raise ValueError("单次检索最多覆盖 31 个自然日")
    if end_day > datetime.now(timezone.utc).date():
        raise ValueError("结束日期不能晚于今天")
    start = datetime.combine(start_day, time.min, tzinfo=timezone.utc)
    end = datetime.combine(end_day, time.max, tzinfo=timezone.utc)
    return start, end


def validate_direction(direction: str) -> str:
    normalized = " ".join(direction.split())
    if len(normalized) < 3:
        raise ValueError("请至少输入 3 个字符的研究方向描述")
    if len(normalized) > 2000:
        raise ValueError("研究方向描述不能超过 2000 个字符")
    return normalized


def generate_arxiv_search_terms(direction: str, llm_config: LLMConfig) -> list[str]:
    """Generate focused English arXiv title/abstract search phrases."""
    prompt = f"""You convert a research direction into focused arXiv search terms.

Research direction supplied by the user:
{direction}

Return a JSON object with key "search_terms" containing 6-12 concise English terms or short phrases.
The terms will be OR-combined against arXiv titles and abstracts.
Rules:
- Preserve named methods, benchmarks, acronyms, organisms, materials, or domains from the input.
- Translate Chinese concepts into standard academic English terminology.
- Prefer discriminative 1-4 word phrases over broad words such as "model", "learning", or "system".
- Cover the main topic and its closest methodological synonyms without drifting into adjacent fields.
- Do not include explanations, Boolean operators, field prefixes, or quotation marks inside terms.

Example: {{"search_terms": ["streaming video understanding", "visual token pruning"]}}"""
    search_config = LLMConfig(
        model=llm_config.model,
        temperature=0.1,
        max_tokens=1024,
    )
    terms = []
    last_error = None
    for _ in range(2):
        response = call_llm(prompt, search_config, json_mode=True)
        try:
            data = _parse_json_object(response)
            terms = data.get("search_terms", [])
            if isinstance(terms, list) and terms:
                break
        except (json.JSONDecodeError, ValueError) as exc:
            last_error = exc
    if not terms:
        raise RuntimeError("DeepSeek 未返回有效的检索词 JSON") from last_error
    cleaned = []
    seen = set()
    for term in terms:
        if not isinstance(term, str):
            continue
        normalized = " ".join(term.replace('"', "").split()).strip()
        if not normalized or len(normalized) > 80 or normalized.lower() in seen:
            continue
        seen.add(normalized.lower())
        cleaned.append(normalized)
    if not cleaned:
        raise RuntimeError("DeepSeek 未能生成有效的 arXiv 检索词")
    return cleaned[:12]


def _parse_json_object(text: str) -> dict:
    """Parse a JSON object even when a provider adds text around it."""
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        data = json.loads(text[start : end + 1])
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object")
    return data


def build_dynamic_config(base: AppConfig, direction: str, search_terms: list[str]) -> AppConfig:
    config = deepcopy(base)
    config.profile = UserProfile(
        topic_interests=[direction],
        required_signals=[],
        negative_filters=[],
        project_context=direction,
        expertise_level="expert",
    )
    config.sources.arxiv.enabled = True
    config.sources.arxiv.categories = []
    config.sources.arxiv.search_terms = search_terms
    config.sources.inspire.enabled = False
    config.output.output_dir = str(PROJECT_ROOT / "output")
    return config


def run_interactive_search(
    start_text: str,
    end_text: str,
    direction_text: str,
    config_path: Path | None = None,
    db_path: Path | None = None,
) -> dict:
    start, end = parse_date_range(start_text, end_text)
    direction = validate_direction(direction_text)
    base = load_config(config_path or PROJECT_ROOT / "config" / "config.yaml")
    search_terms = generate_arxiv_search_terms(direction, base.llm)
    config = build_dynamic_config(base, direction, search_terms)
    result = run_daily_digest(
        config,
        db_path=db_path or PROJECT_ROOT / "data" / "research_radar.db",
        since_date=start,
        until_date=end,
        interactive=False,
        use_rss=False,
    )
    result["search_terms"] = search_terms
    result["direction"] = direction
    return result


def serialize_ranked_paper(ranked) -> dict:
    paper = ranked.paper
    raw_details = paper.raw_metadata.get("author_details", [])
    detail_map = {
        item.get("name", ""): item.get("affiliations", [])
        for item in raw_details
        if isinstance(item, dict)
    }
    authors = []
    for name in paper.authors[:5]:
        authors.append({"name": name, "affiliations": detail_map.get(name, [])})
    return {
        "id": paper.source_id,
        "title": paper.title,
        "chinese_title": ranked.chinese_title,
        "authors": authors,
        "author_count": len(paper.authors),
        "date": paper.submitted_date.strftime("%Y-%m-%d"),
        "url": paper.source_url,
        "pdf_url": paper.pdf_url,
        "score": ranked.relevance_score,
        "abstract_zh": ranked.abstract_zh,
        "introduction": ranked.abstract_takeaway or ranked.summary,
        "research_problem": ranked.research_problem,
        "core_method": ranked.core_method,
        "core_contribution": ranked.core_contribution,
        "relationship": ranked.relationship_to_research or ranked.why_relevant,
        "inspiration": ranked.potential_inspiration,
    }
