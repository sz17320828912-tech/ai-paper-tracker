from src.core.models import Paper
from src.profiles.schema import UserProfile


def build_synonym_prompt(profile: UserProfile) -> str:
    """Build prompt for LLM synonym/related-term expansion."""
    interests = ", ".join(profile.topic_interests) if profile.topic_interests else "not specified"
    context = profile.project_context or "not specified"
    level = profile.expertise_level or "intermediate"
    signals = ", ".join(profile.required_signals) if profile.required_signals else "none"
    negatives = ", ".join(profile.negative_filters) if profile.negative_filters else "none"

    return f"""Let's roleplay. You are a senior academic researcher and domain expert who mentors graduate students. You have deep knowledge of the literature and know exactly which search terms would surface relevant papers versus noise.

A researcher has asked you to help them find papers. Based on their profile, suggest precise search terms that would appear in paper titles and abstracts they'd actually want to read.

**Researcher Profile:**
- Topic interests: {interests}
- Research context: {context}
- Expertise level: {level}
- Must-have signals (terms the researcher specifically cares about): {signals}
- Negative filters (topics to AVOID expanding toward): {negatives}

**Your task:** Generate search terms — synonyms, abbreviations, and closely related concepts — that would help identify papers relevant to THIS SPECIFIC researcher's project.

**Quality rules:**
- ALWAYS include the original topic interests exactly as written — do not rephrase or merge them.
- Add synonyms, abbreviations, and closely related concepts as SHORT terms (1-3 words) that would appear in paper titles or abstracts. Examples: "GNN", "graph neural network", "track fitting", "Kalman filter".
- Anchor expansions around the researcher's must-have signals — these indicate what they consider most important. Generate related terms in those directions.
- Do NOT generate terms related to the negative filters — those are explicitly unwanted.
- Every expanded term should be something THIS researcher would plausibly search for given their project context. Ask yourself: "Would this term appear in a paper this person needs to read?"
- Do NOT generate long phrases like "machine learning for medical imaging" — these are too specific to match. Instead, add the individual concepts: "machine learning", "medical imaging".
- Stay tightly within the researcher's domain. Do NOT expand into adjacent fields unless the researcher's context explicitly bridges them.
- Do NOT pad the list with generic terms (e.g., "supervised learning", "data augmentation") unless directly relevant to the project context.

Return a JSON object with a single key "expanded_terms" containing a flat list of strings. Start with the original terms, then add your short synonyms and related concepts. Aim for 15-25 high-quality terms total — fewer precise terms is better than many vague ones.

Example format:
{{"expanded_terms": ["term1", "term2", "term3"]}}"""


def build_ranking_prompt(papers: list[Paper], profile: UserProfile, min_score: int = 1) -> str:
    """Build prompt for LLM batch ranking + summarization."""
    interests = ", ".join(profile.topic_interests) if profile.topic_interests else "not specified"
    context = profile.project_context or "not specified"
    level = profile.expertise_level or "intermediate"
    signals = ", ".join(profile.required_signals) if profile.required_signals else "none"
    negatives = ", ".join(profile.negative_filters) if profile.negative_filters else "none"

    papers_text = ""
    for i, p in enumerate(papers):
        authors = ", ".join(p.authors[:8])
        if len(p.authors) > 8:
            authors += f" et al. ({len(p.authors)} authors total)"
        papers_text += f"""
---
Paper {i + 1}:
ID: {p.source_id}
Title: {p.title}
Authors: {authors or "not specified"}
Abstract: {p.abstract}
---
"""

    return f"""Let's roleplay. You are a senior academic researcher who screens papers for a colleague. You have decades of experience in their field and understand what makes a paper genuinely useful versus superficially related. You are rigorous — you don't inflate scores just because a paper mentions a relevant keyword.

**Researcher Profile:**
- Topic interests: {interests}
- High-priority signals and reference works: {signals}
- Topics to deprioritize unless there is a direct methodological connection: {negatives}
- Research context: {context}
- Expertise level: {level}

**Papers to evaluate:**
{papers_text}

**Scoring rubric** (use these anchors consistently — most papers should score 3-6, not 8-10):
- **9-10**: Paper's PRIMARY contribution is one of the researcher's listed methods applied to their exact problem domain. Reserve for true must-reads. Most batches will have 0-1 papers at this level.
- **7-8**: Same subfield with directly transferable methods or results. The researcher could cite or build on this work.
- **4-6**: Related field or tangentially useful technique. Interesting but not actionable for their current project.
- **1-3**: Different field, different methods, or only superficial keyword overlap. Being in the same broad discipline is NOT enough for a high score.

**Anti-inflation rules:**
- Sharing a broad topic area is NOT automatic relevance. The methods and application must actually match the researcher's work.
- Sharing a category or venue does not mean relevance. Score based on methodological and topical overlap with the researcher's PROJECT CONTEXT.
- When in doubt, score lower. A 5 is not a bad score — it means "might be interesting".

For each paper, provide:
1. **relevance_score**: integer 1-10 using the rubric above
2. **reasoning**: one sentence explaining why this score, referencing the researcher's specific interests or project context
3. **chinese_title**: an accurate, natural Chinese translation of the paper title
4. **abstract_zh**: a faithful, complete Chinese translation of the supplied abstract; preserve technical terms and numbers
5. **research_problem**: 1-2 Chinese sentences describing the research question, grounded in the abstract
6. **core_method**: 2-4 Chinese sentences describing the core method, grounded in the abstract
7. **core_contribution**: 1-3 Chinese sentences describing the claimed contribution or result, grounded in the abstract
8. **relationship_to_research**: 2-4 Chinese sentences explaining the concrete relationship to this researcher's directions
9. **potential_inspiration**: 1-3 Chinese sentences with specific ideas that may inspire the researcher; clearly label inference when it goes beyond the abstract
10. **abstract_takeaway**: 2-4 Chinese sentences that factually introduce the paper without adding unsupported claims
11. **why_relevant**: a concise Chinese relevance assessment; keep it consistent with relationship_to_research
12. **summary**: a concise Chinese overall summary tailored to expertise level ({level})

Write every explanatory field in Chinese, while preserving English model names, benchmarks, and technical terms where useful. Never fabricate details not present in the supplied title and abstract. If a detail is unavailable, say "摘要未说明" rather than guessing.

**Hard threshold rule:** The configured minimum score is {min_score}/10. For any paper scored below {min_score}, return only paper_id, relevance_score, and reasoning; set every title/summary/detail field to an empty string. Do not spend tokens summarizing below-threshold papers.

Return a JSON object with a single key "papers" containing a list of objects, one per paper, in the same order as provided. Each object must have keys: "paper_id", "relevance_score", "reasoning", "chinese_title", "abstract_zh", "research_problem", "core_method", "core_contribution", "relationship_to_research", "potential_inspiration", "abstract_takeaway", "why_relevant", "summary".

Example format:
{{"papers": [{{"paper_id": "2603.01234v1", "relevance_score": 8, "reasoning": "与输入方向直接相关", "chinese_title": "论文中文标题", "abstract_zh": "摘要的忠实中文翻译", "research_problem": "研究问题", "core_method": "核心方法", "core_contribution": "核心贡献", "relationship_to_research": "与研究方向的关系", "potential_inspiration": "可能的启发", "abstract_takeaway": "基于摘要的事实介绍", "why_relevant": "相关性说明", "summary": "总体总结"}}]}}"""
