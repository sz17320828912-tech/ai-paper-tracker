"""Local API credential loading without printing or copying secret values."""

import json
import os
import re
import subprocess
from pathlib import Path

from dotenv import dotenv_values

PROVIDER_KEYS = {
    "openai": "OPENAI_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
}


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def ensure_provider_key(model: str, root: Path | None = None) -> bool:
    """Load a provider key from environment, .env, or the local api directory."""
    provider = model.split("/", 1)[0].lower()
    key_name = PROVIDER_KEYS.get(provider)
    if key_name is None:
        return True
    if os.environ.get(key_name, "").strip():
        return True

    root = root or project_root()
    env_value = dotenv_values(root / ".env").get(key_name, "")
    if env_value and str(env_value).strip():
        os.environ[key_name] = str(env_value).strip()
        return True

    if provider == "deepseek":
        value = _find_deepseek_key(root / "api")
        if value:
            os.environ[key_name] = value
            return True
    return False


def _find_deepseek_key(api_dir: Path) -> str:
    if not api_dir.is_dir():
        return ""
    for path in sorted(api_dir.iterdir()):
        if not path.is_file():
            continue
        text = _read_credential_file(path)
        value = _extract_key(text)
        if value:
            return value
    return ""


def _read_credential_file(path: Path) -> str:
    if path.suffix.lower() == ".rtf":
        try:
            result = subprocess.run(
                ["textutil", "-convert", "txt", "-stdout", str(path)],
                check=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.stdout
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def _extract_key(text: str) -> str:
    env_match = re.search(r"(?m)^\s*DEEPSEEK_API_KEY\s*=\s*['\"]?([^\s'\"]+)", text)
    if env_match:
        return env_match.group(1)

    try:
        data = json.loads(text)
        if isinstance(data, dict):
            for name in ("DEEPSEEK_API_KEY", "deepseek_api_key", "api_key", "key"):
                value = data.get(name)
                if isinstance(value, str) and value.strip():
                    return value.strip()
    except (json.JSONDecodeError, TypeError):
        pass

    token_match = re.search(r"\b(sk-[A-Za-z0-9_-]{16,})\b", text)
    return token_match.group(1) if token_match else ""
