"""Research Radar CLI — entry point for running digests."""

import argparse
import re
import sys
from datetime import datetime, time, timezone
from pathlib import Path

from src.cli.wizard import run_wizard
from src.core.config import load_config
from src.core.config_validator import validate_config
from src.storage.sqlite import get_connection, purge_old_data
from src.workflows.daily_digest import run_daily_digest

DEFAULT_CONFIG = "config/config.yaml"
DEFAULT_DB = "data/research_radar.db"


def main():
    parser = argparse.ArgumentParser(
        prog="research-radar",
        description="Personalized paper discovery and screening for researchers.",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- digest command ---
    digest_parser = subparsers.add_parser(
        "digest", help="Run a daily digest — fetch, rank, and summarize papers"
    )
    digest_parser.add_argument(
        "--config", "-c",
        default=DEFAULT_CONFIG,
        help=f"Path to config YAML (default: {DEFAULT_CONFIG})",
    )
    digest_parser.add_argument(
        "--db",
        default=DEFAULT_DB,
        help=f"Path to SQLite database (default: {DEFAULT_DB})",
    )
    digest_parser.add_argument(
        "--skip-validation",
        action="store_true",
        default=False,
        help="Skip LLM-based config validation pre-flight check",
    )
    digest_parser.add_argument(
        "--since",
        default=None,
        help="Only include papers submitted on or after this date (YYYY-MM-DD)",
    )
    digest_parser.add_argument(
        "--until",
        default=None,
        help="Only include papers submitted on or before this date (YYYY-MM-DD)",
    )
    digest_parser.add_argument(
        "--no-interactive",
        action="store_true",
        default=False,
        help="Skip interactive prompts (keyword review, etc). Use for CI/headless runs.",
    )
    digest_parser.add_argument(
        "--use-rss",
        action="store_true",
        default=False,
        help="Use arXiv RSS feed instead of API. RSS returns only today's announcements.",
    )

    # --- setup command ---
    setup_parser = subparsers.add_parser(
        "setup", help="Interactive wizard to generate a config file"
    )
    setup_parser.add_argument(
        "--config", "-c",
        default=DEFAULT_CONFIG,
        help=f"Output path for generated config (default: {DEFAULT_CONFIG})",
    )
    setup_parser.add_argument(
        "--model",
        default="openai/gpt-4o-mini",
        help="LLM model to use for config generation (default: openai/gpt-4o-mini)",
    )

    # --- purge command ---
    purge_parser = subparsers.add_parser(
        "purge", help="Delete old runs and orphaned papers from the database"
    )
    purge_parser.add_argument(
        "--older-than",
        required=True,
        help="Delete data older than this duration (e.g. 90d, 6m, 1y)",
    )
    purge_parser.add_argument(
        "--db",
        default=DEFAULT_DB,
        help=f"Path to SQLite database (default: {DEFAULT_DB})",
    )
    purge_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show what would be deleted without actually deleting",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "digest":
        _run_digest(args)
    elif args.command == "setup":
        run_wizard(output_path=args.config, model=args.model)
    elif args.command == "purge":
        _run_purge(args)


def _parse_date(date_str: str, label: str, end_of_day: bool = False) -> datetime:
    """Parse a YYYY-MM-DD date string into an inclusive UTC boundary."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        if end_of_day:
            dt = datetime.combine(dt.date(), time.max)
        return dt.replace(tzinfo=timezone.utc)
    except ValueError:
        print(f"Invalid date format for --{label}: '{date_str}'. Expected YYYY-MM-DD.")
        sys.exit(1)


def _run_digest(args):
    config_path = Path(args.config)

    try:
        config = load_config(config_path)
    except FileNotFoundError:
        print(f"Config file not found: {args.config}")
        print(f"Copy config/config.example.yaml to {args.config} and customize it.")
        sys.exit(1)

    if not args.skip_validation:
        raw_yaml = config_path.read_text()
        warnings = validate_config(raw_yaml, config.llm)

        if warnings:
            print("\n--- Config Validation Warnings ---")
            for i, warning in enumerate(warnings, 1):
                print(f"  {i}. {warning}")
            print("----------------------------------\n")

            answer = input("Proceed anyway? [y/N] ").strip().lower()
            if answer != "y":
                print("Aborted. Please fix your config and try again.")
                sys.exit(1)

    # Parse date window flags
    since_date = _parse_date(args.since, "since") if args.since else None
    until_date = _parse_date(args.until, "until", end_of_day=True) if args.until else None

    if since_date and until_date and since_date > until_date:
        print("Invalid date range: --since must not be later than --until.")
        sys.exit(1)

    interactive = not args.no_interactive
    result = run_daily_digest(
        config,
        db_path=args.db,
        since_date=since_date,
        until_date=until_date,
        interactive=interactive,
        use_rss=args.use_rss,
    )

    print(f"\nDigest complete: {result['stats']['final_count']} papers")
    if result.get("md_path"):
        print(f"  Markdown: {result['md_path']}")
    if result.get("html_path"):
        print(f"  HTML:     {result['html_path']}")
    if not result["ranked_papers"]:
        print("  No papers reached the configured relevance threshold.")


def _parse_duration(duration_str: str) -> int:
    """Parse a duration string like '90d', '6m', '1y' into days."""
    match = re.fullmatch(r"(\d+)\s*([dmy])", duration_str.strip().lower())
    if not match:
        print(f"Invalid duration: '{duration_str}'. Use e.g. 90d, 6m, 1y.")
        sys.exit(1)
    value, unit = int(match.group(1)), match.group(2)
    multipliers = {"d": 1, "m": 30, "y": 365}
    return value * multipliers[unit]


def _run_purge(args):
    days = _parse_duration(args.older_than)
    db_path = Path(args.db)

    if not db_path.exists():
        print(f"Database not found: {db_path}")
        sys.exit(1)

    conn = get_connection(db_path)
    try:
        counts = purge_old_data(conn, older_than_days=days, dry_run=args.dry_run)
    finally:
        conn.close()

    label = "[DRY RUN] Would delete" if args.dry_run else "Deleted"
    print(f"{label}:")
    print(f"  {counts['runs']} run(s)")
    print(f"  {counts['run_papers']} run-paper link(s)")
    print(f"  {counts['orphaned_papers']} orphaned paper(s)")

    if args.dry_run and any(counts.values()):
        print("\nRe-run without --dry-run to actually delete.")


if __name__ == "__main__":
    main()
