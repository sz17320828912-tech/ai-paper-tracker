from datetime import datetime, timezone
from unittest.mock import patch

from src.core.config import LLMConfig, load_config
from src.profiles.schema import UserProfile
from src.ranking.rerank_llm import RankedPaper, rerank_and_summarize
from src.reports.html import generate_html_report
from src.reports.markdown import generate_markdown_report
from src.sources.arxiv_api import ArxivAPI
from tests.conftest import make_paper


def test_local_config_has_expected_defaults():
    config = load_config("config/config.yaml")
    assert config.summary.min_score == 7
    assert config.llm.model == "deepseek/deepseek-flash"
    assert config.output.formats == ["markdown", "html"]
    assert config.sources.inspire.enabled is False


def test_final_reports_only_include_retained_papers_and_chinese_fields():
    retained = make_paper("2609.00001v1", "Streaming Visual Token Selection")
    rejected = make_paper("2609.00002v1", "Unrelated Diffusion Generation")
    ranked = RankedPaper(
        paper=retained,
        relevance_score=9,
        reasoning="直接相关",
        summary="面向流式视频的高效视觉选择方法。",
        chinese_title="流式视觉 Token 选择",
        abstract_zh="本文研究流式视频中的高效视觉选择，并提出基于状态的动态筛选方法。",
        research_problem="研究在线输入中哪些视觉 token 值得进入 ViT。",
        core_method="结合历史状态和运动变化执行 pre-ViT 选择。",
        core_contribution="减少冗余视觉计算并保持时序信息。",
        relationship_to_research="直接对应 pre-ViT selection 与 streaming memory。",
        potential_inspiration="可将状态更新信号用于动态选择预算。",
    )
    stats = {"min_score": 7, "digest_window": "Papers from 2026-09-01 to 2026-09-30"}

    markdown = generate_markdown_report(
        [ranked], pipeline_stats=stats, all_papers=[retained, rejected], total_fetched=2
    )
    html = generate_html_report(
        [ranked], pipeline_stats=stats, all_papers=[retained, rejected], total_fetched=2
    )

    for report in (markdown, html):
        assert "流式视觉 Token 选择" in report
        assert "本文研究流式视频中的高效视觉选择" in report
        assert "研究问题" in report
        assert "核心方法" in report
        assert "核心贡献" in report
        assert "与我的研究方向的关系" in report
        assert "启发" in report
        assert "Unrelated Diffusion Generation" not in report

    assert 'id="paper-search"' in html
    assert 'id="score-filter"' in html
    assert "Relevance Score 9/10" in html


def test_arxiv_query_contains_server_side_inclusive_date_window():
    query = ArxivAPI()._build_query(
        ["cs.CV"],
        None,
        search_terms=["streaming video", "visual token"],
        since_date=datetime(2026, 9, 1, tzinfo=timezone.utc),
        until_date=datetime(2026, 9, 30, 23, 59, tzinfo=timezone.utc),
    )
    assert 'all:"streaming video"' in query
    assert "submittedDate:[202609010000 TO 202609302359]" in query


@patch("src.ranking.rerank_llm.call_llm")
def test_below_threshold_paper_is_not_summarized(mock_llm):
    mock_llm.return_value = """{
      "papers": [{
        "paper_id": "low-score",
        "relevance_score": 4,
        "reasoning": "方向不同",
        "chinese_title": "不应保留的标题",
        "research_problem": "不应保留的摘要",
        "summary": "不应保留的总结"
      }]
    }"""
    paper = make_paper("low-score", "Low score paper")
    result = rerank_and_summarize(
        [paper], UserProfile(topic_interests=["video"]), LLMConfig(), min_score=7
    )
    assert result[0].relevance_score == 4
    assert result[0].chinese_title == ""
    assert result[0].research_problem == ""
    assert result[0].summary == ""
