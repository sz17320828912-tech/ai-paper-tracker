from datetime import datetime, timezone

import pytest

from src.core.config import AppConfig
from src.core.models import Paper
from src.summarization.prompts import build_ranking_prompt
from src.web.app import app
from src.web.service import build_dynamic_config, parse_date_range, validate_direction


def test_date_range_accepts_at_most_31_calendar_days():
    start, end = parse_date_range("2026-09-01", "2026-10-01")
    assert start.day == 1
    assert end.day == 1

    with pytest.raises(ValueError, match="31"):
        parse_date_range("2026-08-31", "2026-10-01")


def test_direction_validation_is_dynamic():
    assert validate_direction("  protein   folding  ") == "protein folding"
    with pytest.raises(ValueError):
        validate_direction("AI")


def test_dynamic_config_removes_fixed_categories_and_profile():
    config = build_dynamic_config(AppConfig(), "量子纠错", ["quantum error correction"])
    assert config.profile.topic_interests == ["量子纠错"]
    assert config.sources.arxiv.categories == []
    assert config.sources.arxiv.search_terms == ["quantum error correction"]


def test_ranking_prompt_only_contains_allowed_paper_metadata():
    paper = Paper(
        source_id="2609.12345v1",
        title="A Test Paper",
        authors=["Alice Example", "Bob Example"],
        abstract="This is the supplied abstract.",
        categories=["secret.category"],
        primary_category="secret.primary",
        submitted_date=datetime(2026, 9, 1, tzinfo=timezone.utc),
        source_url="https://arxiv.org/abs/2609.12345v1",
        pdf_url="https://arxiv.org/pdf/2609.12345v1",
        source_type="arxiv_api",
    )
    prompt = build_ranking_prompt([paper], AppConfig().profile, min_score=7)
    assert "Title: A Test Paper" in prompt
    assert "Authors: Alice Example, Bob Example" in prompt
    assert "Abstract: This is the supplied abstract." in prompt
    assert "secret.category" not in prompt
    assert "secret.primary" not in prompt
    assert "source_url" not in prompt


def test_web_home_and_validation_endpoint():
    client = app.test_client()
    response = client.get("/")
    assert response.status_code == 200
    assert "AI 论文追踪器" in response.get_data(as_text=True)

    invalid = client.post(
        "/api/jobs",
        json={"start": "2026-08-01", "end": "2026-09-30", "direction": "video understanding"},
    )
    assert invalid.status_code == 400
    assert "31" in invalid.get_json()["error"]


def test_health_endpoint_never_returns_secret():
    payload = app.test_client().get("/api/health").get_json()
    assert payload["ok"] is True
    assert payload["model"] == "deepseek/deepseek-flash"
    assert "key" not in payload
    assert set(payload) == {"ok", "model", "min_score", "api_key_ready"}
